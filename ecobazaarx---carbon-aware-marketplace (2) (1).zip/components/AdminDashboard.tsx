import React, { useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area 
} from 'recharts';
import { MOCK_ORDERS } from '../constants';
import { TrendingUp, Users, Package, DollarSign, Leaf, ExternalLink, MousePointer2, Truck, Calendar, Loader2, Check } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [reportStatus, setReportStatus] = useState<'idle' | 'generating' | 'success'>('idle');

  const deliveredCount = MOCK_ORDERS.filter(o => o.status === 'delivered').length;
  
  const stats = [
    { label: 'Total Revenue', value: '$12,450.00', icon: DollarSign, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Website Visits', value: '24,802', icon: MousePointer2, color: 'text-indigo-600', bg: 'bg-indigo-50' },
    { label: 'Successful Deliveries', value: deliveredCount.toString(), icon: Truck, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Carbon Saved', value: '452.8 kg', icon: Leaf, color: 'text-emerald-700', bg: 'bg-emerald-100' },
    { label: 'Orders (Last Week)', value: '42', icon: Calendar, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Orders (Last Month)', value: '184', icon: Calendar, color: 'text-purple-600', bg: 'bg-purple-50' },
  ];

  const salesData = [
    { name: 'Mon', sales: 400, carbon: 20 },
    { name: 'Tue', sales: 300, carbon: 15 },
    { name: 'Wed', sales: 600, carbon: 35 },
    { name: 'Thu', sales: 800, carbon: 45 },
    { name: 'Fri', sales: 500, carbon: 25 },
    { name: 'Sat', sales: 900, carbon: 55 },
    { name: 'Sun', sales: 700, carbon: 40 },
  ];

  const handleExportData = () => {
    setIsExporting(true);
    
    // Simulate data preparation
    setTimeout(() => {
      try {
        const headers = ['Order ID', 'Date', 'Customer', 'Items', 'Total', 'Status', 'Carbon Offset'];
        const csvRows = MOCK_ORDERS.map(order => 
          [order.id, order.date, `"${order.customer}"`, order.items, order.total, order.status, order.carbonOffset].join(',')
        );
        
        const csvContent = [headers.join(','), ...csvRows].join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        
        link.setAttribute('href', url);
        link.setAttribute('download', `ecobazaar_orders_export_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (err) {
        console.error('Export failed:', err);
      } finally {
        setIsExporting(false);
      }
    }, 800);
  };

  const handleGenerateReport = () => {
    setIsGenerating(true);
    setReportStatus('generating');
    
    // Simulate complex report calculation
    setTimeout(() => {
      setReportStatus('success');
      setIsGenerating(false);
      
      // Reset after 3 seconds
      setTimeout(() => setReportStatus('idle'), 3000);
    }, 2000);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900">Admin Command Center</h2>
          <p className="text-slate-500 font-medium">Monitoring global sustainability and sales velocity.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={handleExportData}
            disabled={isExporting}
            className="flex items-center gap-2 bg-white border border-slate-200 text-slate-600 px-5 py-3 rounded-2xl font-bold hover:bg-slate-50 transition-all disabled:opacity-50"
          >
            {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Export CSV'}
          </button>
          <button 
            onClick={handleGenerateReport}
            disabled={isGenerating}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold transition-all shadow-lg ${
              reportStatus === 'success' ? 'bg-emerald-500 text-white' : 'bg-slate-900 text-white hover:bg-emerald-600'
            } disabled:opacity-50`}
          >
            {reportStatus === 'generating' && <Loader2 className="w-4 h-4 animate-spin" />}
            {reportStatus === 'success' && <Check className="w-4 h-4" />}
            {reportStatus === 'idle' && <TrendingUp className="w-4 h-4" />}
            {reportStatus === 'idle' ? 'Generate Report' : reportStatus === 'generating' ? 'Calculating...' : 'Report Ready'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-5 hover:shadow-md transition-shadow">
            <div className={`w-14 h-14 ${stat.bg} ${stat.color} rounded-2xl flex items-center justify-center`}>
              <stat.icon className="w-7 h-7" />
            </div>
            <div>
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
              <h4 className="text-2xl font-black text-slate-900">{stat.value}</h4>
            </div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8 mb-10">
        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold text-slate-900">Sales Volume (Weekly)</h3>
            <div className="px-3 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black rounded-lg">+12% vs last week</div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={salesData}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#059669" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                />
                <Area type="monotone" dataKey="sales" stroke="#059669" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold text-slate-900">Carbon Avoidance Trends</h3>
            <div className="flex items-center gap-1 text-emerald-600 font-bold text-sm">
              <Leaf className="w-4 h-4" /> Eco-Positive
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                />
                <Bar dataKey="carbon" fill="#10b981" radius={[10, 10, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-50 flex justify-between items-center">
          <div>
            <h3 className="text-xl font-bold text-slate-900">Recent Transactions</h3>
            <p className="text-sm text-slate-400 mt-1">Real-time order processing feed.</p>
          </div>
          <button className="text-emerald-600 font-bold text-sm flex items-center gap-1 hover:underline">
            View Ledger <ExternalLink className="w-3 h-3" />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
                <th className="px-8 py-4">Order ID</th>
                <th className="px-8 py-4">Customer</th>
                <th className="px-8 py-4">Status</th>
                <th className="px-8 py-4">Carbon Offset</th>
                <th className="px-8 py-4">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {MOCK_ORDERS.map(order => (
                <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5 font-bold text-slate-900">{order.id}</td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center text-xs font-black text-slate-400">
                        {order.customer.charAt(0)}
                      </div>
                      <span className="text-slate-600 font-medium">{order.customer}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${
                      order.status === 'delivered' ? 'bg-emerald-100 text-emerald-700' : 
                      order.status === 'shipped' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-1.5 text-emerald-600 font-black">
                      <Leaf className="w-3 h-3" /> {order.carbonOffset} kg
                    </div>
                  </td>
                  <td className="px-8 py-5 font-black text-slate-900">${order.total.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;