
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { CartItem } from '../types';
import { Leaf, Info } from 'lucide-react';

interface CarbonDashboardProps {
  items: CartItem[];
}

const COLORS = ['#059669', '#10b981', '#34d399', '#6ee7b7', '#a7f3d0'];

const CarbonDashboard: React.FC<CarbonDashboardProps> = ({ items }) => {
  const totalCarbon = items.reduce((sum, item) => sum + (item.carbonFootprint * item.quantity), 0);
  
  const chartData = items.map(item => ({
    name: item.name,
    value: parseFloat((item.carbonFootprint * item.quantity).toFixed(2))
  }));

  const avgEcoScore = items.length > 0 
    ? Math.round(items.reduce((sum, item) => sum + (item.ecoScore * item.quantity), 0) / items.reduce((s, i) => s + i.quantity, 0))
    : 0;

  return (
    <div className="bg-emerald-50 rounded-[40px] p-8 border border-emerald-100 mb-8 relative overflow-hidden">
      <div className="absolute top-0 right-0 p-8 opacity-10">
        <Leaf className="w-32 h-32 text-emerald-900" />
      </div>
      
      <div className="relative z-10 flex flex-col md:flex-row items-center gap-10">
        <div className="flex-1 text-center md:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest mb-4">
            Environmental Impact Report
          </div>
          <h2 className="text-3xl font-black text-emerald-900 mb-2">Cart Footprint</h2>
          <div className="flex items-baseline gap-2 mb-4 justify-center md:justify-start">
            <span className="text-5xl font-black text-emerald-600">{totalCarbon.toFixed(1)}</span>
            <span className="text-lg font-bold text-emerald-800">kg CO2e</span>
          </div>
          <div className="inline-flex items-center px-4 py-2 bg-white text-emerald-800 rounded-2xl text-sm font-bold shadow-sm border border-emerald-100">
            Average Eco Score: {avgEcoScore}/100
          </div>
        </div>

        {items.length > 0 && (
          <div className="w-56 h-56 flex-shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={65}
                  outerRadius={85}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                   contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontWeight: 'bold' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
      
      <div className="mt-8 pt-8 border-t border-emerald-100/50 flex items-start gap-4">
        <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center flex-shrink-0">
          <Info className="w-5 h-5" />
        </div>
        <p className="text-sm text-emerald-800 leading-relaxed font-medium">
          "Shopping this green collection avoids roughly the same carbon emissions as planting <strong>{ (totalCarbon * 0.1).toFixed(1) } saplings</strong> today. Your choices drive supply chain change."
        </p>
      </div>
    </div>
  );
};

export default CarbonDashboard;
