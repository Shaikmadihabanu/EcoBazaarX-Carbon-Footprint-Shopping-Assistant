
import React, { useState, useRef, useEffect } from 'react';
import { Message, Product, CartItem } from '../types';
import { getEcoAdvice } from '../services/geminiService';
import { MessageSquare, X, Send, Sparkles } from 'lucide-react';

interface EcoAssistantProps {
  products: Product[];
  cart: CartItem[];
}

const EcoAssistant: React.FC<EcoAssistantProps> = ({ products, cart }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Hi! I am EcoBazaar AI. I can help you find products with the lowest carbon footprint or explain our sustainability scores. What\'s on your mind?', timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const aiResponse = await getEcoAdvice(input, products, cart);
    const assistantMessage: Message = { role: 'assistant', content: aiResponse, timestamp: new Date() };
    
    setMessages(prev => [...prev, assistantMessage]);
    setIsLoading(false);
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-emerald-600 text-white rounded-2xl shadow-2xl flex items-center justify-center hover:bg-emerald-700 hover:scale-105 transition-all z-50 group"
      >
        {isOpen ? <X className="w-8 h-8" /> : <MessageSquare className="w-8 h-8 group-hover:animate-pulse" />}
      </button>

      {isOpen && (
        <div className="fixed bottom-24 right-6 w-[400px] h-[600px] max-h-[80vh] bg-white rounded-[40px] shadow-3xl flex flex-col z-50 border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-10 duration-500">
          <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold leading-tight">Eco Advisor</h4>
                <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest">Powered by Gemini AI</p>
              </div>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50 no-scrollbar">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-3xl text-sm shadow-sm ${
                  m.role === 'user' 
                    ? 'bg-emerald-600 text-white rounded-br-none font-medium' 
                    : 'bg-white text-slate-800 border border-slate-100 rounded-bl-none'
                }`}>
                  {m.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex gap-1.5">
                  <div className="w-2 h-2 bg-emerald-300 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-emerald-300 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-emerald-300 rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
            )}
          </div>

          <div className="p-6 bg-white border-t border-slate-100">
            <div className="flex gap-3 bg-slate-50 p-2 rounded-2xl border border-slate-100">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="How do you calculate eco-scores?"
                className="flex-1 bg-transparent px-3 py-2 text-sm focus:outline-none"
              />
              <button 
                onClick={handleSend}
                disabled={isLoading}
                className="p-3 bg-slate-900 text-white rounded-xl hover:bg-emerald-600 transition-all disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default EcoAssistant;
