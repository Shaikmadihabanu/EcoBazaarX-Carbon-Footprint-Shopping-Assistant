
import { GoogleGenAI } from "@google/genai";
import { Product, CartItem } from "../types";

export const getEcoAdvice = async (userPrompt: string, products: Product[], cart: CartItem[]) => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    return "The AI assistant is currently in demo mode as no API Key was detected. I can help you find products like the Solar Backpack or Organic Bedding!";
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const productContext = products.slice(0, 10).map(p => 
    `${p.name}: Carbon Footprint ${p.carbonFootprint}kg, Eco Score ${p.ecoScore}/100, Materials: ${p.materials.join(', ')}`
  ).join('\n');

  const cartContext = cart.length > 0 
    ? `Current Cart: ${cart.map(c => `${c.name} (Qty: ${c.quantity})`).join(', ')}`
    : "Cart is currently empty.";

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Context: You are EcoBazaar AI, a sustainability expert for a premium e-commerce platform.
Available Sustainable Products:
${productContext}

User Status:
${cartContext}

User query: ${userPrompt}

Goal: Provide expert, friendly, and data-driven sustainability advice. Suggest specific products from the list if relevant. Keep it under 100 words.`,
    });

    return response.text || "I'm processing that... sustainability is a journey!";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "My eco-processors are briefly offline. How else can I help you today?";
  }
};
